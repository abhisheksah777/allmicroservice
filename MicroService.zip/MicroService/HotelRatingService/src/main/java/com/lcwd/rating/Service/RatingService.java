package com.lcwd.rating.Service;

import java.util.List;

import com.lcwd.rating.Entity.Rating;

public interface RatingService {

	Rating saveRating(Rating rating);

	List<Rating> getRating();

	Rating getRatingByid(String ratingid);
	List<Rating> getUserByid(String userid);
	List<Rating> getHotelByid(String hotelid);
    
}
