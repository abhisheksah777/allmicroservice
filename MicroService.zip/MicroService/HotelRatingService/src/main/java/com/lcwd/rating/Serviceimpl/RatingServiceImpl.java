package com.lcwd.rating.Serviceimpl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lcwd.rating.Entity.Rating;
import com.lcwd.rating.Exception.ResourceNotFoundException;
import com.lcwd.rating.Repositroy.RatingRepositroy;
import com.lcwd.rating.Service.RatingService;

@Service
public class RatingServiceImpl implements RatingService {
	@Autowired
	private RatingRepositroy ratingRepositroy;

	@Override
	public Rating saveRating(Rating rating) {
		String randomid = UUID.randomUUID().toString();
		rating.setRatingId(randomid);
		return ratingRepositroy.save(rating);
	}

	@Override
	public List<Rating> getRating() {
		return ratingRepositroy.findAll();
	}

	@Override
	public Rating getRatingByid(String ratingid) {
		return ratingRepositroy.findById(ratingid)
				.orElseThrow(() -> new ResourceNotFoundException("Resource Not Found On Server !!" + " " + ratingid));
	}

	@Override
	public List<Rating> getUserByid(String userid) {
		return ratingRepositroy.findByUserId(userid);
	}

	@Override
	public List<Rating>getHotelByid(String hotelid) {
		return ratingRepositroy.findByHotelId(hotelid);
	}

}
