package com.lcwd.rating.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lcwd.rating.Entity.Rating;
import com.lcwd.rating.Serviceimpl.RatingServiceImpl;

@RestController
@RequestMapping("/rating")
public class RatingController {
	@Autowired
	private RatingServiceImpl ratingServiceImpl;

	@PostMapping()
	public ResponseEntity<Rating> insertRating(@RequestBody Rating Rating) {
		Rating saveRating = ratingServiceImpl.saveRating(Rating);
		return new ResponseEntity<Rating>(HttpStatus.CREATED).ok(saveRating);

	}

	@GetMapping("/{ratingid}")
	public ResponseEntity<Rating> getRating(@PathVariable String ratingid) {
		Rating getRating = ratingServiceImpl.getRatingByid(ratingid);
		return new ResponseEntity<Rating>(HttpStatus.ACCEPTED).ok(getRating);

	}

	@GetMapping()
	public ResponseEntity<List<Rating>> getAllRating() {
		List<Rating> allRating = ratingServiceImpl.getRating();
		return new ResponseEntity<List<Rating>>(HttpStatus.ACCEPTED).ok(allRating);

	}

	@GetMapping("/user/{userid}")
	public ResponseEntity<List<Rating>> getAllUserByid(@PathVariable String userid) {
		List<Rating> allRating = ratingServiceImpl.getUserByid(userid);
		return new ResponseEntity<List<Rating>>(HttpStatus.ACCEPTED).ok(allRating);

	}

	@GetMapping("/hotel/{hotelid}")
	public ResponseEntity<List<Rating>> getAllhotelByis(@PathVariable String hotelid) {
		List<Rating> allRating = ratingServiceImpl.getHotelByid(hotelid);
		return new ResponseEntity<List<Rating>>(HttpStatus.ACCEPTED).ok(allRating);

	}
}
