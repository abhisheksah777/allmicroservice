package com.example.User.Service.Repository;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.User.Service.Entity.User;
@EnableAutoConfiguration
public interface UserRespository extends JpaRepository<User, String> {

}
