package com.example.User.Service.Service;

import java.util.List;

import com.example.User.Service.Entity.User;

public interface UserService {

	public User saveUser(User user);
	public List<User> getAllUser();
	public User getUser(String userid);
//	public User updateUser(String userid);
//	public String deleteUser(String userid);
}
