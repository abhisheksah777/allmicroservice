package com.example.User.Service.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.User.Service.Entity.User;
import com.example.User.Service.ServiceImple.UserServiceImpl;

@RestController
@RequestMapping("/users")
public class UserController {
	@Autowired
	private UserServiceImpl userServiceImpl;
	
	@PostMapping()
	public ResponseEntity<User> insertUser(@RequestBody User user) {
		User saveUser = userServiceImpl.saveUser(user);
		return new ResponseEntity<User>(HttpStatus.CREATED).ok(saveUser);

	}

	@GetMapping("/{userId}")
	public ResponseEntity<User> getUser(@PathVariable String userId) {
		User getuser = userServiceImpl.getUser(userId);
		return new ResponseEntity<User>(HttpStatus.ACCEPTED).ok(getuser);

	}

	@GetMapping()
	public ResponseEntity<List<User>> getAllUser() {
		List<User> alluser = userServiceImpl.getAllUser();
		return new ResponseEntity<List<User>>(HttpStatus.ACCEPTED).ok(alluser);

	}

}
