package com.example.User.Service.ServiceImple;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.User.Service.Entity.Hotel;
import com.example.User.Service.Entity.Rating;
import com.example.User.Service.Entity.User;
import com.example.User.Service.Exception.ResourceNotFoundException;
import com.example.User.Service.Repository.UserRespository;
import com.example.User.Service.Service.UserService;

import ch.qos.logback.classic.Logger;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRespository userRespository;
	@Autowired
	private RestTemplate restTemplate;

	private Logger logger = (Logger) LoggerFactory.getLogger(UserServiceImpl.class);

	@Override
	public User saveUser(User user) {
		String randomUserId = UUID.randomUUID().toString();
		user.setUserId(randomUserId);
		return userRespository.save(user);
	}

	@Override
	public List<User> getAllUser() {
		// fetch rating of the above user from RATING SERVICE:Using Rest Template
		return userRespository.findAll();
	}

	@Override
	public User getUser(String userid) {
//Get User  from database with the help of user Respository
//		String resourceUrl="http://localhost:8083/rating/user/155b0e0b-788f-43a2-a749-e24520315bbb";
		User user = userRespository.findById(userid)
				.orElseThrow(() -> new ResourceNotFoundException("Resource Not Found On Server !!" + " " + userid));
		// fetch rating of the above user from RATING SERVICE
		// http://localhost:8083/rating/user/155b0e0b-788f-43a2-a749-e24520315bbb
		Rating[] ratingforUser = restTemplate.getForObject("http://RATINGSERVICE/rating/user/" + user.getUserId(),
				Rating[].class);
		List<Rating> ratings = Arrays.stream(ratingforUser).toList();
		List<Rating> ratingList = ratings.stream().map(rating -> {
			// api call to hotel service to get the hotel
			// http://localhost:8082/hotel/9d07db8a-46f5-42c3-bfbc-2be615e20f83
			ResponseEntity<Hotel> forEntity = restTemplate
					.getForEntity("http://HOTELSERVICE/hotel/" + rating.getHotelId(), Hotel.class);
			Hotel hotel = forEntity.getBody();
			logger.info("Response Status Code {}", forEntity.getStatusCode());

			// set the hotel to rating
			rating.setHotel(hotel);
			// return the rating
			return rating;

		}).collect(Collectors.toList());
		user.setRating(ratingList);

//		logger.info("{}", forObject);
		return user;
	}

}
