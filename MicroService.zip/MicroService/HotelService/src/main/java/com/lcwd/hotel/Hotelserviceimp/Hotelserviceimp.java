package com.lcwd.hotel.Hotelserviceimp;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lcwd.hotel.Entity.Hotel;
import com.lcwd.hotel.Exception.ResourceNotFoundException;
import com.lcwd.hotel.Repository.HotelRespositroy;
import com.lcwd.hotel.service.HotelService;
@Service
public class Hotelserviceimp implements HotelService {
	@Autowired
	private HotelRespositroy hotelRespositroy;

	@Override
	public Hotel saveHotel(Hotel hotel) {
		String ramdomhotelid = UUID.randomUUID().toString();
		hotel.setId(ramdomhotelid);
		return hotelRespositroy.save(hotel);
	}

	@Override
	public List<Hotel> getAllhotel() {
		return hotelRespositroy.findAll();
	}

	@Override
	public Hotel getHotelByid(String hotelid) {
		return hotelRespositroy.findById(hotelid)
				.orElseThrow(() -> new ResourceNotFoundException("Resource Not Found On Server !!" + " " + hotelid));
	}

}
