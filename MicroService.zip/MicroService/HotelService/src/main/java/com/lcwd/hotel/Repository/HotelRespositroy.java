package com.lcwd.hotel.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lcwd.hotel.Entity.Hotel;

public interface HotelRespositroy extends JpaRepository<Hotel, String> {

}
